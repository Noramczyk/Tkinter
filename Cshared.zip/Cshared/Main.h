void Main();
char byte_to_ascii(char b);
char hex_to_ascii(char c);

